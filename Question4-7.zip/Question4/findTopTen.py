"""
Find top ten rank using T-test
@author : Liu Shizhe
"""

from scipy import stats
from csv import reader
import numpy as np
import heapq

def fLoadDataMatrix(filename):
    #打开文件，导入数据
    with open(filename,'r') as raw_data:
        readers = reader(raw_data,delimiter='\t')
        x = list(readers)
        data = np.array(x)
    
    row_num = data.shape[0]         # 行数量 = 样本数量 + 1
    col_num = data.shape[1]         # 列数量 = 特征/基因数量 + 1
    
    Gene = data[1 : row_num, 0]     # 0列是基因名字    
    Sample = data[0, 1 : col_num]   # 0行是样本
    Matrix = data[1 : row_num, 1 : col_num]
    Pos = list()                    # 阳性样本的位置
    Neg = list()                    # 阴性样本的位置
    for i in range(col_num - 1):
        if Sample[i] == 'POS':
            Pos.append(i)
        elif Sample[i] == 'NEG':
            Neg.append(i)
    return Gene, Pos, Neg, Matrix


if __name__ == '__main__':
    Gene, Pos, Neg, Matrix = fLoadDataMatrix('ALL3.txt')
    matrix_row = Matrix.shape[0]
    Pvalues = list()                # 保存特征/基因的Pvalue的值   
    for i in range(matrix_row):
        sample = Matrix[i]
        dataP = sample[Pos].astype(np.float64)
        dataN = sample[Neg].astype(np.float64)
        Tvalue, Pvalue = stats.ttest_ind(dataP, dataN)
        Pvalues.append(Pvalue)
    
    top_num = 10                    # 取最的的10个基因
    top_numbers = heapq.nsmallest(top_num, Pvalues)  # 各基因Pvalue值前10小的值 
    top_index = list()              # 基因Pvalue值前10大的值所在的位置索引
    
    for t in top_numbers:
        index = Pvalues.index(t)
        top_index.append(index)
        Pvalues[index] = 0
    
    print('the names of top 10 ranked features are:')
    # 按行输出显著性差异排名前n的基因名字
    for i in range(top_num):
        print(Gene[ top_index[i] ]) 
