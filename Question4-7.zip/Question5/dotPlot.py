"""
Dot plots of t-test based
@author : Liu Shizhe
注：可以调用Question4写的函数，这里选择直接复制过来
"""

from scipy import stats
from csv import reader
import numpy as np
import heapq


def fLoadDataMatrix(filename):
    # 打开文件，导入数据
    with open(filename, 'r') as raw_data:
        readers = reader(raw_data, delimiter='\t')
        x = list(readers)
        data = np.array(x)

    row_num = data.shape[0]  # 行数量 = 样本数量 + 1
    col_num = data.shape[1]  # 列数量 = 特征/基因数量 + 1

    Gene = data[1: row_num, 0]  # 0列是基因名字
    Sample = data[0, 1: col_num]  # 0行是样本
    Matrix = data[1: row_num, 1: col_num]
    Pos = list()  # 阳性样本的位置
    Neg = list()  # 阴性样本的位置
    for i in range(col_num - 1):
        if Sample[i] == 'POS':
            Pos.append(i)
        elif Sample[i] == 'NEG':
            Neg.append(i)
    return Gene, Pos, Neg, Matrix


if __name__ == '__main__':
    """Gene是基因名字，Pos记录所有阳性位置，Neg记录所有阴性位置，Matrix是数据矩阵"""

    Gene, Pos, Neg, Matrix = fLoadDataMatrix('ALL3.txt')
    matrix_row = Matrix.shape[0]
    Pvalues = list()  # 保存特征/基因的Pvalue的值
    for i in range(matrix_row):
        sample = Matrix[i]
        dataP = sample[Pos].astype(np.float64)
        dataN = sample[Neg].astype(np.float64)
        Tvalue, Pvalue = stats.ttest_ind(dataP, dataN)
        Pvalues.append(Pvalue)

    top_num = 10001  # 取最小的10001个基因
    top_numbers = heapq.nsmallest(top_num, Pvalues)  # 各基因Pvalue值前10小的值 
    top_index = list()  # 基因Pvalue值前10001大的值所在的位置索引

    for t in top_numbers:
        index = Pvalues.index(t)
        top_index.append(index)
        Pvalues[index] = 0

    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(2, 2)
    axs = list()                                # 其实可以用axes = ax.flatten()
    axs.append(axes[0, 0])
    axs.append(axes[0, 1])
    axs.append(axes[1, 0])
    axs.append(axes[1, 1])
    # ax2=axes[0, 1]

    compare_num = [1, 9, 1000, 10000]
    for i in range(4):
        cnum = compare_num[i] - 1               # 需要取排名第几的gene,注意-1
        rank1 = Matrix[top_index[cnum]]         # 把rank1做为横坐标
        rank2 = Matrix[top_index[cnum + 1]]     # rank2做为纵坐标
        xcordP = rank1[Pos].astype(np.float64)  # 阳性样本-x
        ycordP = rank2[Pos].astype(np.float64)  # 阳性样本-y
        xcordN = rank1[Neg].astype(np.float64)  # 阴性样本-x
        ycordN = rank2[Neg].astype(np.float64)  # 阴性样本-y
        
        # 调用scatter绘制散点图
        axs[i].scatter(xcordP, ycordP, s=30, c='red', marker='s')
        axs[i].scatter(xcordN, ycordN, s=30, c='green')

    axs[0].set_title('Rank1 vs Rank2')
    axs[0].set_xlabel('Rank1')                   # 标记它的第一个横坐标为Rank1
    axs[0].set_ylabel('Rank2')                   # 标记它的第一个纵坐标为Rank2
    
    axs[1].set_title('Rank9 vs Rank10')
    axs[1].set_xlabel('Rank9')
    axs[1].set_ylabel('Rank10')
    
    axs[2].set_title('Rank1000 vs Rank1001', y = -0.3)  # y设置成负数是为了显示在坐标轴下面
    axs[2].set_xlabel('Rank1000')
    axs[2].set_ylabel('Rank1001')
    
    axs[3].set_title('Rank10000 vs Rank10001', y=-0.3)
    axs[3].set_xlabel('Rank10000')
    axs[3].set_ylabel('Rank10001')
    
    plt.show()
