"""
Define a function: 
(Sample, Class, Feature, Matrix) = fLoadDataMatrix(FileName)
 
"""
from csv import reader
import numpy as np
import configparser


def fLoadDataMatrix(filename):
    #打开文件，导入数据
    with open(filename,'r') as raw_data:
        readers = reader(raw_data,delimiter='\t')
        x = list(readers)
        data = np.array(x)
    
    row_num = data.shape[0]                         # 行数量 = 样本数量 + 1
    col_num = data.shape[1]                         # 列数量 = 特征/基因数量 + 1
    
    Feature = data[1 : row_num, 0]                  # 0列是特征/基因名字    
    Sample = data[0, 1 : col_num]                   # 0行是样本名字
    Matrix = data[1 : row_num, 1 : col_num].T       # 之所以转置是为了换成行是样本，列是特征的形式
    Matrix = Matrix.astype(np.float64)              # 注意还得转换类型
    
    label = []
    cf = configparser.ConfigParser()                
    cf.read('config.ini')                           # 读取配置文件
    pos_name = cf.get('file', 'pos_name')           # 读取阳性名字
    neg_name = cf.get('file', 'neg_name')           # 读取阴性名字
    
    for i in range(col_num - 1):
        if Sample[i] == pos_name:
            label.append(1)
        elif Sample[i] == neg_name:
            label.append(0)
    Class = np.array(label)

    return Sample, Class, Feature, Matrix
