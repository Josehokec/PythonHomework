"""
Find top ten rank using T-test
@author : Liu Shizhe
"""

from scipy import stats
from csv import reader
import numpy as np
import heapq
import configparser
from copy import deepcopy


def getPvalues(Sample, Class, Feature, Matrix):
    """
    功能：求各个特征的Pvalues值
    参数：样本名字，类别，特征名字，数据矩阵，topK的值
    返回：Pvalues值的矩阵
    """
    pos = np.array(np.where(Class == 1))[0]     # 这么操作变成的是二维矩阵，所以有[0]
    neg = np.array(np.where(Class == 0))[0]
    matrix_row = Matrix.shape[1]
    Pvalues = list()                # 保存特征/基因的Pvalue的值   
    for i in range(matrix_row):
        s = Matrix[:, i]            # 矩阵的第i列数据，即某个特征/基因
        dataP = s[pos]
        dataN = s[neg]
        Tvalue, Pvalue = stats.ttest_ind(dataP, dataN)
        Pvalues.append(Pvalue)
    
    return Pvalues

def findTopK(Pvalues, Feature):
    """
    功能：找到T检验排名前K的特征所在位置的索引
    参数：各个特征的Pvalues的值
    返回：k个索引位置的列表，并将topK的名字结果保存到指定文件中去
    """
    
    cf = configparser.ConfigParser()                
    cf.read('config.ini')                           # 读取配置文件
    topK = cf.get('findTop', 'topK')                # 读取topK的值
    output_dir  = cf.get('file', 'output_dir')      # 输出文件的dir
    filename = cf.get('findTop', 'filename')        # 输出结果文件
    temp_Pvalues = deepcopy(Pvalues)                # 深拷贝
    
    top_num = int(topK)                             # 取最的的K个基因
    top_numbers = heapq.nsmallest(top_num, temp_Pvalues) 
    top_index = list()                              # 基因Pvalue值前topK大的值所在的位置索引
    
    for t in top_numbers:
        index = temp_Pvalues.index(t)
        top_index.append(index)
        temp_Pvalues[index] = 0
    
    f = open(output_dir + '/' + filename, mode='w')
    f.write('the names of top 10 ranked features are :\n')
    for i in range(top_num):
        f.write(Feature[ top_index[i] ])            # 按行输出显著性差异排名前n的基因名字
        f.write('\n')

    return np.array(top_index)
