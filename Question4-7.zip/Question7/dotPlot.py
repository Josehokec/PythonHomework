"""
Dot plots of t-test based
@author : Liu Shizhe
"""

from scipy import stats
from csv import reader
import numpy as np
import heapq
import configparser
import matplotlib.pyplot as plt


def getRankIndex(Pvalues, k_arr):
    """
    功能：得到Pvalues中排第k的特征的索引
    参数：Pvalues向量，要查的k数组
    返回：索引向量
    """
    indexs = np.array(Pvalues).argsort()      # 元素从小到大排列，提取其对应的index索引
    indexs = np.array(indexs)
    
    return indexs[k_arr]


def plotDotGram(Class, Feature, Matrix, Pvalues):
    """
    功能：画出2*2的散点图
    输入：类别，特征/基因名字，数据矩阵，P值
    输出：将图片保存到输出文件中去
    """
    rankX = [0, 8, 999, 9999]                   # 注意要减1
    rankY = [1, 9, 1000, 10000]                 # 注意要减1
    index1 = getRankIndex(Pvalues, rankX)
    index2 = getRankIndex(Pvalues, rankY)
    
    pos = np.array(np.where(Class == 1))
    neg = np.array(np.where(Class == 0))
    plt.figure(figsize=(10,7))
    for i in range(4):
        plt.subplot(2, 2, 1 + i)
        xData = Matrix[:, index1[i]]            # 横坐标的数据
        yData = Matrix[:, index2[i]]            # 纵坐标的数据
        xcordP = xData[pos]                     # 阳性样本-x
        ycordP = yData[pos]                     # 阳性样本-y
        xcordN = xData[neg]                     # 阴性样本-x
        ycordN = yData[neg]                     # 阴性样本-y
        
        plt.scatter(xcordP, ycordP, s=30, c='red', marker='s')
        plt.scatter(xcordN, ycordN, s=30, c='green')
        
        xlabel_name = Feature[ index1[i] ]
        ylabel_name = Feature[ index2[i] ]
        
        plt.xlabel(xlabel_name)                 # 标记它的横坐标为xlabel_name
        plt.ylabel(ylabel_name)                 # 标记它的纵坐标为ylabel_name
    
    cf = configparser.ConfigParser()                
    cf.read('config.ini')                           # 读取配置文件
    output_dir = cf.get('file', 'output_dir')
    filename = cf.get('dotGram', 'dotgram_name')    # 读取阳性名字
    plt.savefig(output_dir + '/' + filename)
    
    plt.show()
