from loadData import fLoadDataMatrix
from findTopTen import getPvalues
from findTopTen import findTopK
from dotPlot import plotDotGram
from histogram import plotHistogram

import configparser


cf = configparser.ConfigParser()                # 得到配置解释器句柄         
cf.read('config.ini')                           # 读取配置文件
filename = cf.get('file', 'filename')           # 得到文件名字

# Question 3
Sample, Class, Feature, Matrix = fLoadDataMatrix(filename)

# Question 4
Pvalues = getPvalues(Sample, Class, Feature, Matrix)
findTopK(Pvalues, Feature)

# Question 5
plotDotGram(Class, Feature, Matrix, Pvalues)

# Question 6
plotHistogram(Pvalues, Class, Matrix)
