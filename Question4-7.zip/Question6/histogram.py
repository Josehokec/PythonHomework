"""
绘制分类器的结果直方图--并列的柱状图
由于柱状图每条没标数字，我会将中间结果显示出来
author: Liu Shizhe
"""

from scipy import stats
from csv import reader
import numpy as np
import heapq

from sklearn.neighbors.classification import KNeighborsClassifier
from sklearn import svm                     # 导入支持向量机的分类器
from sklearn.naive_bayes import GaussianNB  # 导入高斯朴素贝叶斯分类器

from sklearn.model_selection import KFold   # 交叉验证需要用的包

import matplotlib.pyplot as plt

import warnings
warnings.filterwarnings("ignore")           # 程序运行时sklearn某一个模块有警告，忽略警告

def fLoadDataMatrix(filename):
    # 打开文件，导入数据
    with open(filename, 'r') as raw_data:
        readers = reader(raw_data, delimiter='\t')
        x = list(readers)
        data = np.array(x)

    row_num = data.shape[0]         # 行数量 = 样本数量 + 1
    col_num = data.shape[1]         # 列数量 = 特征/基因数量 + 1

    Gene = data[1: row_num, 0]      # 0列是基因名字
    Sample = data[0, 1: col_num]    # 0行是样本
    Matrix = data[1: row_num, 1: col_num]
    Pos = list()                    # 阳性样本的位置
    Neg = list()                    # 阴性样本的位置
    Class = list()                  # 类标签
    for i in range(col_num - 1):
        if Sample[i] == 'POS':
            Pos.append(i)
            Class.append(1)         # 1代表阳性
        elif Sample[i] == 'NEG':
            Neg.append(i)
            Class.append(0)         # 0代表阴性
    return Gene, Pos, Neg, Matrix, Class


def counter_TN_TP_FN_FP(X_pred, y_test):
    """
    统计一组数据中，TN、TP、FN、FP的数量
    参数是预测的数组和测试数组
    返回TN, TP, FN, FP, 样本长度
    """
    TP = 0; TN = 0; FN = 0; FP = 0
    for i in range(len(y_test)):
        if(X_pred[i] == 1 and y_test[i] == 1):  
            TP = TP + 1                 #True positive
        elif(X_pred[i] == 1 and y_test[i] == 0):
            FP = FP + 1                 #False positive
        elif(X_pred[i] == 0 and y_test[i] == 1):
            FN = FN + 1                 #False negative
        elif(X_pred[i] == 0 and y_test[i] == 0):
            TN = TN + 1                 #True negative
    
    return TN, TP, FN, FP


def cal_result(TP, TN, FP, FN):
    """
    计算预测结果的Sn, Sp, Acc, Avc, MCC
    参数：TP TN FP FN
    返回：Sn, Sp, Acc, Avc, MCC
    注意MCC的坟墓可能会碰到0，与需要做特判
    """
    Sn = Sn = TP / (TP + FN)
    Sp = TN / (TN + FP)
    Acc = (TP + TN) / (TP + TN + FN + FP)
    Avc = (Sn + Sp) / 2
    temp = ((TP + FP) * (TP + FN) * (TN + FP) * (TN + FN)) ** 0.5
    if temp == 0.0 :
        MCC = 0
    else:
        MCC = (TP * TN - FP * FN) / temp
    return Sn, Sp, Acc, Avc, MCC


if __name__ == '__main__':
    """Gene是基因名字，Pos记录所有阳性位置，Neg记录所有阴性位置，Matrix是数据矩阵"""

    Gene, Pos, Neg, Matrix, Class = fLoadDataMatrix('ALL3.txt')
    matrix_row = Matrix.shape[0]
    Pvalues = list()  # 保存特征/基因的Pvalue的值
    for i in range(matrix_row):
        sample = Matrix[i]
        dataP = sample[Pos].astype(np.float64)
        dataN = sample[Neg].astype(np.float64)
        Tvalue, Pvalue = stats.ttest_ind(dataP, dataN)
        Pvalues.append(Pvalue)
    
    two_pair = [ (Pvalues[i], i) for i in range(matrix_row) ] 
    
    """
    indexs[x]记录top x + 1在原来的数据集的索引
    如indexs[0]记录了t检验后pvalue的值最大的基因索引
    升序，需要reverse
    """
    indexs =  [var for _,var in sorted(two_pair, reverse = False)]
    
    values = [1, 10, 100, -100]                 # 对应top-1 top-10 top-100 buttom-100
    svm = svm.SVC()
    nbayes = GaussianNB()
    knn = KNeighborsClassifier(n_neighbors=1)
    clf = [svm, nbayes, knn]                    # clf数组保存三个分类器指针
    
    fig, axes = plt.subplots(2, 2)              # 四个结果保存到一张图中
    axs = list()                                # 用列表/数组存指针，可以将其摊开成一维数组
    axs.append(axes[0, 0])
    axs.append(axes[0, 1])
    axs.append(axes[1, 0])
    axs.append(axes[1, 1])
    
    
    for i in range( len(values) ):
        """
        确定用哪一个特征来做训练
        注意top-X是值用排名前X的来训练
        """
        
        flag = values[i]
        top_buttom_K = []                       # top or buttom K real index
        if flag > 0:
            for item in range(flag):
                top_buttom_K.append( indexs[item] )
        else:
            while(flag < 0):
                top_buttom_K.append( indexs[flag] )
                flag = flag + 1
        
        # print('number :', i)
        # print(top_buttom_K)
        # 提取保留的特征，然后做特征选择
        X = Matrix[top_buttom_K].astype(np.float64).T
        y = np.array(Class)              
        
        clf_results = []                        # 存储各个分类器的结果 应该是一个3x5的矩阵
        
        for j in range( len(clf) ):
            """确定用哪一个分类器来训练"""
            times = 30              # 随机分30次
            Sns = []                # Sn = TP / (TP + FN) 阳性样本预测对的
            Sps = []                # Sp = TN / (TN + FP) 阴性样本预测对的
            Accs = []               # Acc = (TP + TN) / (TP + TN + FN + FP)
            Avcs = []               # Avc = (Sn + Sp) / 2
            MCCs = []               # MCC = baidu
        
            for k in range(times):
                """
                k应该没用到
                由于分割样本集训练集是随机的，所以需要循环来求结果
                """
                kf = KFold(n_splits = 10, shuffle = True)             # 样本均分五份
                # TN : True negative | TP : True positive | FN : False Negative | FP : False Positive
                TNs = []; TPs = []; FNs = []; FPs = []         
            
                for train, test in kf.split(X,y):
                    """训练并测试 注意只有一个特征的时候需要reshape"""
                    if X.shape[1] == 1:
                        clf[j].fit(X[train].reshape(-1, 1).astype(np.float64),y[train].astype(np.float64))  #训练分类器
                        X_pred = clf[j].predict(X[test].reshape(-1, 1).astype(np.float64))
                    else:
                        clf[j].fit(X[train].astype(np.float64),y[train].astype(np.float64))  #训练分类器
                        X_pred = clf[j].predict(X[test].astype(np.float64))
                        
                    tn, tp, fn, fp = counter_TN_TP_FN_FP(X_pred, y[test])
                    TNs.append(tn); TPs.append(tp); FNs.append(fn); FPs.append(fp)
           
                Sn, Sp, Acc, Avc, MCC = cal_result(sum(TPs), sum(TNs), sum(FPs), sum(FNs) )
                Sns.append(Sn); Sps.append(Sp); Accs.append(Acc)
                Avcs.append(Avc); MCCs.append(MCC)
        
            average_sn = np.mean(Sns); average_sp = np.mean(Sps)
            average_acc = np.mean(Accs); average_avc = np.mean(Avcs)
            average_mcc = np.mean(MCCs)
        
            results = []            # 某一个分类器的五个值的结果列表
            results.append(average_sn); results.append(average_sp); results.append(average_acc)
            results.append(average_avc); results.append(average_mcc)
            clf_results.append(results)

        # 接下来就是对于这个单个特征训练结果来画直方图了
        x = np.arange(5)
        y1 = clf_results[0]
        y2 = clf_results[1]
        y3 = clf_results[2]
        print('selected featrue order : ', i)
        print(clf_results)

        bar_width = 0.27
        tick_label = ["Sn", "Sp", "Acc", "Avc", "MCC"]

        axs[i].bar(x, y1, bar_width, align="center", color="c", label="SVM", alpha=0.5)
        axs[i].bar(x + bar_width, y2, bar_width, color="b", align="center", label="Nbayes", alpha=0.5)
        axs[i].bar(x + bar_width * 2, y3, bar_width, color="r", align="center", label="Knn", alpha=0.5)
        
        axs[i].set_xticks(x + bar_width / 2)        # 设置间距
        axs[i].set_xticklabels(tick_label)          # 设置x轴标签名称
        # plt.xticks(x + bar_width / 2, tick_label)
        axs[i].legend()                             # 标名含义
    
    axs[0].set_title('Top-1')
    axs[1].set_title('Top-10')
    axs[2].set_title('Top-100')
    axs[3].set_title('Buttom-100')
    plt.show()
